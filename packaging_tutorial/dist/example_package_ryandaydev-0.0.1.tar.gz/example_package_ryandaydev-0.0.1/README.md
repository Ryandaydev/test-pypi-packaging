# test-pypi-packaging
Testing the process of publishing to pypi

## Purpose
This is a project I'm only testing to see how Python packaging works

## Decisions
Using hatchling for the build